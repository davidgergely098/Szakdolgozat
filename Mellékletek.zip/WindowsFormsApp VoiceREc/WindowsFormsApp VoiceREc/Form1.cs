﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Speech.Recognition;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Header;

namespace WindowsFormsApp_VoiceREc
{

    public partial class Form1 : Form
    {
        private double currentTemperature;
        private double lastTemperature;
        private double targetTemperature = 24.0;
        private int timeLeft = 60;
        private int energyleft = 60;
        string selectedLocation = "kint";
        SpeechSynthesizer synthesizer = new SpeechSynthesizer();
        public const string TurOnLamp = "kapchold fel a lámpát";
        public const string TurnDownLamp = "kapchold le a lámpát";
        public const string CloseTheCourtain = "engedd le a rehdoynt";
        public const string OPenTheCourtain = "hoozd fel a rehdoynt";
        public const string LivingRoom = "napphaliban";
        public const string Kitchen = "konyhaban";
        public const string BedRoom = "haloszobaban";
        public const string KidsRoom = "gyerekszobaban";
        public const string WorkingRoom = "dolgozoszobaban";
        public const string BathRoom = "furdoszobaban";
        public const string Corridor = "foyoson";
        public const string CloseLock = "zaard be azayytoot";
        public const string Openlock = "gnesd keaz aytoht";
        public const string WaterThePlant = "ontozd meg a viragot";
        public const string Help = "shehgeetsheg";
        public const string Outside = "Kint";



        SpeechRecognitionEngine engine = new SpeechRecognitionEngine();
        public Form1()
        {
            InitializeComponent();

            synthesizer.SelectVoiceByHints(VoiceGender.Female, VoiceAge.Adult, 0, new System.Globalization.CultureInfo("hu-HU")); //Felolvaso hangja (nincs magyar ezert defaultot hasznal)
        }


        private void PictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox1.Invalidate();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            Choices commands = new Choices();
            commands.Add(new string[] { TurOnLamp, TurnDownLamp, CloseTheCourtain, OPenTheCourtain, LivingRoom, Kitchen, BedRoom, KidsRoom, WorkingRoom, BathRoom, Corridor, CloseLock, Openlock, WaterThePlant , Help });
            GrammarBuilder builder = new GrammarBuilder();
            builder.Append(commands);
            Grammar grammar = new Grammar(builder);

            

            engine.LoadGrammarAsync(grammar);
            engine.SetInputToDefaultAudioDevice(); // alapértelmezett hangfelismerőt használja
            engine.SpeechRecognized += Engine_SpeechRecognized;

            Timer timer = new Timer();
            timer.Interval = 5000; // Frissítési időköz (pl. 5000 milliszekundum)
            timer.Tick += Timer_Tick;
            timer.Start();

            Timer approachTimer = new Timer();
            approachTimer.Interval = 1000; // 1 másodperc
            approachTimer.Tick += ApproachTimer_Tick;
            approachTimer.Start();

            Random rnd = new Random();
            lastTemperature = rnd.Next(1000, 3200) / 100.0;
        }

        private void Engine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
                string[] selectedLocations = new string[] { "nappali", "konyha", "haloszoba", "gyerekszoba", "dolgozoszoba", "furdoszoba", "kint" };

            bool outside;
            if (selectedLocation == "kint")
            {
                outside = true;
            }
            else
            {
                outside = false;
            }

                switch (e.Result.Text)
                {
                    case Openlock:
                        pictureBox42.Visible = true;
                        richTextBox1.Text += "\najtó kinyitva ";
                    break;
                    case CloseLock:
                        richTextBox1.Text += "\najtó bezárva ";
                    pictureBox42.Visible = false;
                    break;
                    case LivingRoom:
                        if (outside == true && pictureBox42.Visible == false)
                        {
                            richTextBox1.Text += "\nnem tudok bemenni a zárt ajtón";
                        break;
                    }
                        CleanupPreviousLocation();
                        pictureBox24.Visible = true;
                        selectedLocation = "nappali";
                        richTextBox1.Text += "\nselectedLocation = nappali";
                        break;
                    case Kitchen:

                    if (outside == true && pictureBox42.Visible == false)
                    {
                        richTextBox1.Text += "\nnem tudok bemenni a zárt ajtón";
                        break;
                    }
                        CleanupPreviousLocation();
                        pictureBox23.Visible = true;
                        selectedLocation = "konyha";
                        richTextBox1.Text += "\nselectedLocation = konyha";
                        break;
                    case BedRoom:
                    if (outside == true && pictureBox42.Visible == false)
                    {
                        richTextBox1.Text += "\nnem tudok bemenni a zárt ajtón";
                        break;
                    }
                    CleanupPreviousLocation();
                        pictureBox28.Visible = true;
                        selectedLocation = "haloszoba";
                        richTextBox1.Text += "\nselectedLocation = haloszoba";
                        break;
                    case KidsRoom:
                    if (outside == true && pictureBox42.Visible == false)
                    {
                        richTextBox1.Text += "\nnem tudok bemenni a zárt ajtón";
                        break;
                    }
                    CleanupPreviousLocation();
                        pictureBox30.Visible = true;
                        selectedLocation = "gyerekszoba";
                        richTextBox1.Text += "\nselectedLocation = gyerekszoba";
                        break;
                    case WorkingRoom:
                    if (outside == true && pictureBox42.Visible == false)
                    {
                        richTextBox1.Text += "\nnem tudok bemenni a zárt ajtón";
                        break;
                    }
                    CleanupPreviousLocation();
                        pictureBox25.Visible = true;
                        selectedLocation = "dolgozoszoba";
                        richTextBox1.Text += "\nselectedLocation = dolgozoszoba";
                        break;
                    case BathRoom:
                    if (outside == true && pictureBox42.Visible == false)
                    {
                        richTextBox1.Text += "\nnem tudok bemenni a zárt ajtón";
                        break;
                    }
                    CleanupPreviousLocation();
                        pictureBox29.Visible = true;
                        selectedLocation = "furdoszoba";
                        richTextBox1.Text += "\nselectedLocation = furdoszoba";
                        break;
                    case Outside:
                    if (outside == false && pictureBox42.Visible ==false)
                    {
                        richTextBox1.Text += "\nnem tudok kimenni a zárt ajtón";
                        break;
                    }
                        CleanupPreviousLocation();
                        pictureBox27.Visible = true;
                        selectedLocation = "kint";
                        richTextBox1.Text += "\nselectedLocation = kint";
                        break;
                    case Corridor:
                    if (outside == true && pictureBox42.Visible == false)
                    {
                        richTextBox1.Text += "\nnem tudok bemenni a zárt ajtón";
                        break;
                    }
                    CleanupPreviousLocation();
                        pictureBox26.Visible = true;
                        selectedLocation = "folyoso";
                        richTextBox1.Text += "\nselectedLocation = folyoso";
                        break;


                    case TurOnLamp:
                    richTextBox1.Text += "\nLámpa felkapcsolva";
                        switch (selectedLocation)
                        {
                            case "folyoso":
                                pictureBox18.Visible = true;
                                break;
                            case "nappali":
                                pictureBox21.Visible = true;
                                richTextBox1.Text += "\nLámpa felkapcsolva a nappaliban";
                                break;
                            case "konyha":
                                pictureBox4.Visible = true;
                                break;
                            case "gyerekszoba":
                                pictureBox14.Visible = true;
                                break;
                            case "furdoszoba":
                                pictureBox20.Visible = true;
                                break;
                            case "dolgozoszoba":
                                pictureBox11.Visible = true;
                                break;
                            case "haloszoba":
                                pictureBox16.Visible = true;
                                break;
                        }
                        break;

                    case TurnDownLamp :
                        richTextBox1.Text += "\nLámpa lekapcsolva";
                        switch (selectedLocation)
                        {
                            case "folyoso":
                                pictureBox18.Visible = false;
                                break;
                            case "nappali":
                                pictureBox21.Visible = false;
                                break;
                            case "konyha":
                                pictureBox4.Visible = false;
                                break;
                            case "gyerekszoba":
                                pictureBox14.Visible = false;
                                break;
                            case "furdoszoba":
                                pictureBox20.Visible = false;
                                break;
                            case "dolgozoszoba":
                                pictureBox11.Visible = false;
                                break;
                            case "haloszoba":
                                pictureBox16.Visible = false;
                                break;
                        }
                        break;
                    case CloseTheCourtain :
                        richTextBox1.Text += "\nFüggöny becsukva";
                        switch (selectedLocation)
                        {
                            case "nappali":
                                pictureBox2.Visible = true;
                                pictureBox5.Visible = true;
                                pictureBox8.Visible = true;
                                break;
                            case "konyha":
                                pictureBox2.Visible = true;
                                pictureBox5.Visible = true;
                                pictureBox8.Visible = true;
                                break;
                            case "gyerekszoba":
                                pictureBox9.Visible = true;
                                break;
                            case "dolgozoszoba":
                                pictureBox7.Visible = true;
                                break;
                            case "haloszoba":
                                pictureBox6.Visible = true;
                                pictureBox10.Visible = true;
                                break;
                        }
                        richTextBox1.Text += "\nredőny leengedve";
                        break;
                    case "hoozd fel a rehdoynt":
                        switch (selectedLocation)
                        {
                            case "nappali":
                                pictureBox2.Visible = false;
                                pictureBox5.Visible = false;
                                pictureBox8.Visible = false;
                                break;
                            case "konyha":
                                pictureBox2.Visible = false;
                                pictureBox5.Visible = false;
                                pictureBox8.Visible = false;
                                break;
                            case "gyerekszoba":
                                pictureBox9.Visible = false;
                                break;
                            case "dolgozoszoba":
                                pictureBox7.Visible = false;
                                break;
                            case "haloszoba":
                                pictureBox6.Visible = false;
                                pictureBox10.Visible = false;
                                break;
                        }
                        richTextBox1.Text += "\nredőny felhúzva";
                        break;
                    case "ontozd meg a viragot":
                    if (selectedLocation == "konyha" || selectedLocation == "nappali") {
                        timeLeft = 100;
                        richTextBox1.Text += "\nvirág megöntözve";
                        break;
                    }
                    richTextBox1.Text+= "\nItt nincs virág";
                    break;
                    case "shehgeetsheg":
                    richTextBox1.Clear();
                    richTextBox1.Text+= "\nA jelenleg értelmezett parancsok: \nkapcsold fel a lámpát \nkapcsold le a lámpát \n engedd le a redőnyt \nhúd fel a redőnyt\n nappaliban\nkonyhában \nháloszobában \ngyerekszobában \ndolgozoszobában \nfürdőszobában \nfolyoson \nzárd be az ajtót\nnyisd ki az ajtót\nöntözd meg a virágot";
                    break;
            }
                richTextBox1.SelectionStart = richTextBox1.Text.Length;
                richTextBox1.ScrollToCaret();
            

        }
        private void CleanupPreviousLocation()
        {
            pictureBox23.Visible = false;
            pictureBox24.Visible = false;
            pictureBox25.Visible = false;
            pictureBox26.Visible = false;
            pictureBox27.Visible = false;
            pictureBox28.Visible = false;
            pictureBox29.Visible = false;
            pictureBox30.Visible = false;
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            if (pictureBox42.Visible == true)
            {
                pictureBox32.Visible = true;
                pictureBox37.Visible = true;
                pictureBox38.Visible = true;
                pictureBox39.Visible = true;
                pictureBox40.Visible = true;
            }
            else
            {
                pictureBox32.Visible = false;
                pictureBox37.Visible = false;
                pictureBox38.Visible = false;
                pictureBox39.Visible = false;
                pictureBox40.Visible = false;
            }
            Random rnd = new Random();
            currentTemperature = rnd.Next(1000, 3400) / 100.0; // Random hőmérséklet 10 és 34 között
            double change = rnd.Next(-200, 200) / 100.0; // Véletlenszerű változás -2.0 és +2.0 között
            double newTemperature =+ change;

            // Hőmérséklet határainak biztosítása 10 és 32 fok között
            if (newTemperature < 10)
                newTemperature = 10;
            if (newTemperature >= 32)
                newTemperature = 31;

            label2.Text = "Kinti Jelenlegi hőmérséklet: " + currentTemperature.ToString("0.0") + " °C";



            // Hangszint frissítése
            int soundLevel = engine.AudioLevel;

            // Ha a hangszint negatív érték, akkor a mikrofon nem érzékeli hangot
            if (soundLevel >= 0)
            {
                // Frissítjük a label1 feliratát a hangszint alapján
                label1.Text = "Mikrofon hangszint: " + soundLevel.ToString();
            }
            else
            {
                // Ha a hangszint negatív, akkor a mikrofon nem érzékeli hangot
                label1.Text = "Nincs hangérzékelés";
            }
            if (timeLeft > 0)
            {
                timeLeft--; // Csökkenti az időt
                timeProgressBar.Value = timeLeft;
            }
            else
            {
                MessageBox.Show("A növényt megöntöztük");
                timeLeft = 100;
            }
            if (timeLeft < 50) {
                pictureBox46.Visible = false;
                pictureBox45.Visible = true;
            }
            else
            {
                pictureBox46.Visible = true;
                pictureBox45.Visible = false;
            }
            if (energyleft > 0)
            {
                energyleft-=5;
                progressBar1.Value = energyleft;
            }
            if (currentTemperature>18)
            {
                energyleft += 10;
            }
            if (energyleft > 100) {
                energyleft = 100;
            }
            if (energyleft == 0) { 
                pictureBox20.Visible = false;
                pictureBox4.Visible = false;
                pictureBox18.Visible = false;
                pictureBox16.Visible = false;
                pictureBox14.Visible = false;
                pictureBox11.Visible = false;
                pictureBox21.Visible = false;
            }
        }
        private void ApproachTimer_Tick(object sender, EventArgs e)
        {
            double difference = targetTemperature - currentTemperature;
            if (Math.Abs(difference) <= 1.0)
            {
                currentTemperature += difference * 0.5; // Ha a különbség kisebb vagy egyenlő 1-nél, akkor 0.5-el közelítjük
            }
            else
            {
                currentTemperature += difference / Math.Abs(difference); // Egyébként 1-el közelítjük
            }
            label3.Text = "Benti hőmérséklet: " + currentTemperature.ToString("0.00") + " °C";
            if (currentTemperature < 24)
            {
                pictureBox44.Visible = false;
            }
            else {
                pictureBox44.Visible = true;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text += "\nBeszédfelismerés elkezdődött";
            engine.RecognizeAsync(RecognizeMode.Multiple);
            string text = "Seeya, oodvehzohlekaz ókosh hazban";
            //string text = "foyoson";
            synthesizer.SpeakAsync(text);
        }
        private void InitializeProgressBar()
        {
            timeProgressBar.Maximum = timeLeft;
            timeProgressBar.Value = timeLeft;
        }
        private void InitializeProgressBar1()
        {
            progressBar1.Maximum = energyleft;
            progressBar1.Value = energyleft;
        }
    }
}